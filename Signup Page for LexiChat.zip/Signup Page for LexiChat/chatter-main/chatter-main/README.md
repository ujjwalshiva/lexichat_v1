# Chatter App

Hello There! this is an instant chatting app based on Firebase API. It works in real time and is designed using HTML, CSS and Vanilla JS. Neumorphism Design standards are maintained to give it a cool look while chatting. The usernames and user logos are dynamic and is based on statically API that generates dynamic user avatars.

## Website Link: https://ujjwalshiva.github.io/chatter/

## Screenshots

![image](https://user-images.githubusercontent.com/81429137/160670054-898fe7eb-7794-4274-90ab-7e7d06232e6b.png)

